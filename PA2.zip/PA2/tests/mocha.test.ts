// suppress console logging so output of mocha is clear
before(function () {
});
  